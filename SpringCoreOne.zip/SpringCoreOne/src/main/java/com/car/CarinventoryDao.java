
package com.car;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class CarinventoryDao {
	@Autowired
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void saveData(CarinventoryPojo car) {
		String insertcarInfo = "insert into car values(" + car.getId() + ",'" + car.getMake() + "','" + car.getModel()
				+ "','" + car.getYear() + "','" + car.getSalesPrice() + "')";
		jdbcTemplate.update(insertcarInfo);
	}

	public List<CarinventoryPojo> getAllCarRowMapper() {
		return jdbcTemplate.query("select * from car", new RowMapper<CarinventoryPojo>() {
			public CarinventoryPojo mapRow(ResultSet rs, int rownumber) throws SQLException {
				CarinventoryPojo e = new CarinventoryPojo();
				e.setId(rs.getInt(1));
				e.setMake(rs.getString(2));
				e.setModel(rs.getString(3));
				e.setYear(rs.getInt(4));
				e.setSalesPrice(rs.getFloat(5));
				return e;
			}
		});
	}
}
