package com.car;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CarInventoryMain {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		CarinventoryPojo b = (CarinventoryPojo) context.getBean("edao");
		Scanner sr = new Scanner(System.in);
		System.out.println("please enter add,list,quit");
		String action = sr.next();
		while (!action.equals("quit")) {
			switch (action) {
			case "add":
				System.out.println("enter the value for id=");

				b.setId(sr.nextInt());
				System.out.println("enter the value for Make=");

				b.setMake(sr.next());

				System.out.println("enter the value for Model=");

				b.setModel(sr.next());

				System.out.println("enter the value for year=");
				b.setYear(sr.nextInt());
				System.out.println("enter the value for Price=");
				b.setSalesPrice(sr.nextFloat());

				CarinventoryDao dao = context.getBean("cdao", CarinventoryDao.class);
				dao.saveData(b);
				System.out.println("data saved sucessfully");
				System.out.println("please enter action add,list,quit");
				action = sr.next();
				break;
			case "list":
				CarinventoryDao dao1 = context.getBean("cdao", CarinventoryDao.class);
				List<CarinventoryPojo> list = dao1.getAllCarRowMapper();
				list.forEach(carInfo -> System.out.println(carInfo));
				System.out.println("please enter action add,list,quit");
				action = sr.next();
				break;
			default:
				System.out.println("please enter Valid Command like add,list,quit");
				action = sr.next();
			}

		}
		System.out.println("Goodbye!!!!");
	}
}
