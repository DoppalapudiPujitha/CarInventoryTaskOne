
package com.car;

public class CarinventoryPojo {
	private int id;
	private String make;
	private String model;
	private int year;
	private float salesPrice;

	public float getSalesPrice() {
		return salesPrice;
	}

	public void setSalesPrice(float salesPrice) {
		this.salesPrice = salesPrice;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	void display() {
		System.out.println(make + " " + model + " " + year + " " + " " + salesPrice);
	}

	public String toString() {
		return id + " " + model + " " + model + " " + year + " " + salesPrice;
	}

}